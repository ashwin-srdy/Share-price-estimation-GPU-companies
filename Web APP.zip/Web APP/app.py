import pickle
from flask import Flask , request, render_template
app = Flask(__name__)
model = pickle.load(open("lr.pkl","rb"))
@app.route('/')
def indput():
    return render_template('index.html')

@app.route("/prediction",methods = ['GET','POST'])
def predict():
    #date=eval(request.form["date"])
    low=eval(request.form["low"])
    high=eval(request.form["high"])
    volume=eval(request.form["volume"])
    open=eval(request.form["open"])
    company=eval(request.form["company"])
    year=eval(request.form["year"])
    month=eval(request.form["month"])
    day=eval(request.form["day"])
    print(year)
    xx=model.predict([[open,high,low,volume,year,month,day,company]])
    out=xx[0]

    print("Forecasted closing price on {}/{}/{} is $ {}".format(day,month,year,out))
    
    return render_template("index.html",p="Forecasted closing price on {}/{}/{} is $ {}".format(day,month,year,out))
if __name__ == '__main__':
    app.run(debug = False)